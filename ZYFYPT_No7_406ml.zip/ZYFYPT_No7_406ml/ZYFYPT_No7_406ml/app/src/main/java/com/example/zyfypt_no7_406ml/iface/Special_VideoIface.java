package com.example.zyfypt_no7_406ml.iface;

public interface Special_VideoIface {
    void getVideoList(String mod, int page, String sessionID,Special_VideoListener special_videoListener);
}
