package com.example.zyfypt_no7_406ml.iface;

public interface ProjectIface {
    void getProjectList(String mod,int page,String SessionID,ProjectListener projectListener);
}
