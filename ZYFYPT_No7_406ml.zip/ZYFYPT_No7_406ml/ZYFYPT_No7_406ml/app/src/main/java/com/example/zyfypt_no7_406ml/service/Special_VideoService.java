package com.example.zyfypt_no7_406ml.service;

import com.example.zyfypt_no7_406ml.bean.Video;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface Special_VideoService {
    @GET("api.php/listspecial")
    Call<List<Video>> getVideoList(@Query("mod") String mod,
                                   @Query("page") int page,
                                   @Query("SessionID") String SessionID);
}
