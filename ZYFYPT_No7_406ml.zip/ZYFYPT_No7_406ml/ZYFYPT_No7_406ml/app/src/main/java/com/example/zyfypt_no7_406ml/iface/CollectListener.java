package com.example.zyfypt_no7_406ml.iface;

public interface CollectListener {
    void onResponse(String msg);
    void onFail(String msg);

}
