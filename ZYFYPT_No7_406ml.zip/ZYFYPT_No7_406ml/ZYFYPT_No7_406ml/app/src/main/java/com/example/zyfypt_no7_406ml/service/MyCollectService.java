package com.example.zyfypt_no7_406ml.service;

import com.example.zyfypt_no7_406ml.bean.Article;
import com.example.zyfypt_no7_406ml.bean.CollectResult;
import com.example.zyfypt_no7_406ml.bean.Tcase;
import com.example.zyfypt_no7_406ml.bean.Video;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MyCollectService {
    @GET("api.php/listmycollect/mod/collect{mod}")
    Call<List<CollectResult<Article>>> getCarticleList(@Path("mod")String mod, @Query("page") int page, @Header("SessionID") String sessionID);

    @GET("api.php/listmycollect/mod/collect{mod}")
    Call<List<CollectResult<Video>>> getCvideoList(@Path("mod")String mod, @Query("page") int page, @Header("SessionID") String sessionID);

    @GET("api.php/listmycollect/mod/collect{mod}")
    Call<List<CollectResult<Tcase>>> getCCaseList(@Path("mod")String mod, @Query("page") int page, @Header("SessionID") String sessionID);
}
