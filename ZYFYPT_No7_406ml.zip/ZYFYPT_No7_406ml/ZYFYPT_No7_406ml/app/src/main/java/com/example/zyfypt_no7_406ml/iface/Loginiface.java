package com.example.zyfypt_no7_406ml.iface;

public interface Loginiface {
    void getLoginResult(String username,
                        String pass,
                        LoginListener loginListener);

}
