package com.example.zyfypt_no7_406ml.iface;

public interface MyCVideoIface {
    void getMyVideoList(String mod, int page, String SessionID, MyCVideoListener mycollectListener);
}
