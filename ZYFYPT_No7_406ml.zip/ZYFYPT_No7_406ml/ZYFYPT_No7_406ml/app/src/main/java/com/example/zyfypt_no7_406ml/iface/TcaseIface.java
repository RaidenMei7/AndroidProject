package com.example.zyfypt_no7_406ml.iface;

public interface TcaseIface {
    void getTcaseList(String mod,int page,String SessionID,TcaseListener tcaseListener);
}
