package com.example.zyfypt_no7_406ml.iface;

public interface Latest_VideoIface {
    void getVideoList(String mod, int page, String sessionID,Latest_VideoListener latest_videoListener);
}
