package com.example.zyfypt_no7_406ml.iface;

public interface TwareIface {
    void getTwareList(String mod,int id,String SessionID,TwareListener twareListener);
}
