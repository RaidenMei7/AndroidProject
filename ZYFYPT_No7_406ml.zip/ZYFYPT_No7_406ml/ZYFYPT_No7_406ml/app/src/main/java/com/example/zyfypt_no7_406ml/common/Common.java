package com.example.zyfypt_no7_406ml.common;

public class Common {
    public static String BASEURL="http://amicool.neusoft.edu.cn/";
    public static  String IMAGEURL="http://amicool.neusoft.edu.cn/Uploads/";
    public static String  ARTICLEURL="http://amicool.neusoft.edu.cn/article.php/show/index/id/";
    public static String  TCASEURL="http://amicool.neusoft.edu.cn/tcase.php/show/index/id/";
    public static String  PROJECTURL="http://amicool.neusoft.edu.cn/project.php/show/index/id/";

}
