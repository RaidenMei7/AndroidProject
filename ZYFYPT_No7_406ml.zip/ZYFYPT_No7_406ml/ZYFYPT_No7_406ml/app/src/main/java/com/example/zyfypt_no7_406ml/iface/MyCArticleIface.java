package com.example.zyfypt_no7_406ml.iface;

public interface MyCArticleIface {
    void getListMyCollect(String mod, int page, String SessionID, MyCArticleListener mycollectListener);
}
