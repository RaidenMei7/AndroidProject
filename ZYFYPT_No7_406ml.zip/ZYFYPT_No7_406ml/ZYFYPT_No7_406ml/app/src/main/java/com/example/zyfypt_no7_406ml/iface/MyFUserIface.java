package com.example.zyfypt_no7_406ml.iface;

public interface MyFUserIface {
    void getListMyFocus(String mod, int page, String SessionID, MyFUserListener myFUserListener);
}
