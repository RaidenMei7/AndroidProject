package com.example.zyfypt_no7_406ml.iface;

public interface MyCTcaseIface {
    void getListMyCollect(String mod, int page, String SessionID, MyCTcaseListener mycollectListener);
}
