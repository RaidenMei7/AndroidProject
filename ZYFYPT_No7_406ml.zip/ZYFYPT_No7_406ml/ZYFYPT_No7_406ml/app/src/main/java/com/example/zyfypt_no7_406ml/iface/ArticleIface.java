package com.example.zyfypt_no7_406ml.iface;

public interface ArticleIface {
    void getArticleList(String mod,int page,String SessionID,ArticleListener articleListener);
}
