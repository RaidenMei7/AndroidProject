package com.example.zyfypt_no7_406ml.service;

import com.example.zyfypt_no7_406ml.bean.Article;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ArticleService {

    @GET("api.php/lists")
    Call<List<Article>> getArticleList(
            @Query("mod") String mod,
            @Query("page") int page,
            @Query("SessionID") String sessionID
    );
}
