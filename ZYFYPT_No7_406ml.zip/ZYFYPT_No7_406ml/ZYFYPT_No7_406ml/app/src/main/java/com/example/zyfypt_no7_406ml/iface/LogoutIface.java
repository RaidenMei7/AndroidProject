package com.example.zyfypt_no7_406ml.iface;

public interface LogoutIface {
    void logout(String sessionID);
}
