package com.example.zyfypt_no7_406ml.iface;

public interface FocusListener {
    void onResponse(String msg);
    void onFail(String msg);
}
